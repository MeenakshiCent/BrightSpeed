﻿using IntelliCAD.EditorInput;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teigha.DatabaseServices;
using Teigha.Geometry;
namespace LUMENCADPlacementTool
{
    internal class RotateJig : EntityJig
    {
        // Declare some internal state
        double m_baseAngle, m_deltaAngle;
        Point3d m_rotationPoint;
        Matrix3d m_ucs;

        // Constructor sets the state and clones
        // the entity passed in
        // (adequate for simple entities)
        //for rotating block reference feature
        public RotateJig(BlockReference ent, Point3d rotationPoint, double baseAngle, Matrix3d ucs) : base(ent.Clone() as BlockReference)
        {
            m_rotationPoint = rotationPoint;
            m_baseAngle = baseAngle;
            m_ucs = ucs;
        }
        //for rotating text entity feature feature
        public RotateJig(DBText ent, Point3d rotationPoint, double baseAngle, Matrix3d ucs) : base(ent.Clone() as DBText)
        {
            m_rotationPoint = rotationPoint;
            m_baseAngle = baseAngle;
            m_ucs = ucs;
        }

        public RotateJig(MText ent, Point3d rotationPoint, double baseAngle, Matrix3d ucs) : base(ent.Clone() as MText)
        {
            m_rotationPoint = rotationPoint;
            m_baseAngle = baseAngle;
            m_ucs = ucs;
        }

        protected override SamplerStatus Sampler(JigPrompts jp)
        {
            // throw new NotImplementedException();
            // We acquire a single angular value
            JigPromptAngleOptions jo = new JigPromptAngleOptions("\nAngle of rotation: ");
            jo.BasePoint = m_rotationPoint;
            jo.UseBasePoint = true;
            PromptDoubleResult pdr = jp.AcquireAngle(jo);
            if (pdr.Status == PromptStatus.OK)
            {
                // Check if it has changed or not
                // (reduces flicker)
                if (m_baseAngle == pdr.Value)
                {
                    return SamplerStatus.NoChange;
                }
                else
                {
                    // Set the change in angle to
                    // the new value
                    m_deltaAngle = pdr.Value;
                    return SamplerStatus.OK;
                }
            }
            return SamplerStatus.Cancel;
        }

        protected override bool Update()
        {
            //throw new NotImplementedException();
            // Filter out the case where a zero delta is provided
            if (m_deltaAngle > Tolerance.Global.EqualPoint)
            {
                // We rotate the polyline by the change
                // minus the base angle
                Matrix3d trans = Matrix3d.Rotation(
                    m_deltaAngle - m_baseAngle,
                    m_ucs.CoordinateSystem3d.Zaxis,
                    m_rotationPoint);
                Entity.TransformBy(trans);
                // The base becomes the previous delta
                // and the delta gets set to zero
                m_baseAngle = m_deltaAngle;
                m_deltaAngle = 0.0;
            }

            return true;
        }
        public Entity GetEntity()
        {
            return Entity;
        }
        public double GetRotation()
        {
            // The overall rotation is the
            // base plus the delta
            return m_baseAngle + m_deltaAngle;

        }
    }
}
