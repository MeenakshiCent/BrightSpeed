﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _907_integration
{
    public class Constants
    {
        //DA Boundary
        public static string daBoundary_lyrName = "DA Boundary";
        public static string daBoundary_Linetype = "Bylayer";
        public static string daBoundary_Color = "Bylayer";
        public static double daBoundary_lineWeight = -1.0;
        public static double daBoundary_LineTypeScale = 1.0;
        public static double daBoundary_GlobalWidth = 5.0;

        //Feeder
        public static string FeederCable_lyrName = "Feeder Cable";
        public static string FeederCable_Linetype = "Bylayer";
        public static string FeederCable_Color = "Bylayer";
        public static double FeederCable_lineWeight = 0.18;
        public static double FeederCable_LineTypeScale = 0.5;
        public static double FeederCable_GlobalWidth = 0.5;

        //MST Tail
        public static string MSTTail_lyrName = "MST Tail";
        public static string MSTTail_Linetype = "Bylayer";
        public static string MSTTail_Color = "Bylayer";
        public static double MSTTail_lineWeight = -1.0;
        public static double MSTTail_LineTypeScale = 1.0;
        public static double MSTTail_GlobalWidth = 0.5;

        public static string FreezeLayers = "Background map Image,Grids_View Port,Streetnames_Overview,Overview map";
        public static string streetNameLayer = "StreetNames";


        //hh10X10 mtext
        public static string HH_MText_lyrName = "TEXT_HH_ Annotaion";
        public static double HH_MText_Height = 3.7500;
        public static byte[] HH_MText_Color = new byte[] { 255, 0, 0 };
        public static double HH_MText_Width = 0;
        public static double HH_MText_RotationAngle = 0;
        public static string HH_MText_Style = "ARIAL";
        public static double HH_MText_LineTypeScale = 1;


        ////Trech layer Names
        public static string trench_LyrName = "New UG";
        public static string trench_Linetype = "DASHED2";
        public static int trench_Color = 1;
        public static double trench_lineWeight = 0.18;
        public static double trench_LineTypeScale = 0.4;
        public static double trench_GlobalWidth = 0.7;
        public static double trench_offsetVal = 3.0;
        public static string row_LyrName = "Right_Of_Way";
        ////Trech layer Names
        public static string exTrench_LyrName = "Existing UG";
        public static string exTrench_Linetype = "DASHED2";
        public static int exTrench_Color = 256;
        public static double exTrench_lineWeight = 0.18;
        public static double exTrench_LineTypeScale = 0.4;
        public static double exTrench_GlobalWidth = 0.7;
        public static double exTrench_offsetVal = 3.0;

        //existing
        public static string ExistingHandhole_lyrName = "_SYMBOL_HH-HANDHOLE-Existing";
        public static string ExistingHandhole_BlkName = "Existing Handhole";//"HH EX";

        public static string FlowerPot_lyrName = "_SYMBOL_FP-FLOWER POT";
        public static string FlowerPot_BlkName = "FLOWER POT";


        //handhole
        public static string Handhole_lyrName = "_SYMBOL_HH-HANDHOLE";
        public static string Handhole_BlkName = "HANDHOLE";
        public static string Handhole_LineType = "Continuous";

     
    }
}
