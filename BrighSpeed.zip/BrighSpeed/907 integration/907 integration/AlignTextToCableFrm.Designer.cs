﻿namespace _907_integration
{
    partial class AlignTextToCableFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkBoxReverse = new System.Windows.Forms.CheckBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chkBoxReverse
            // 
            this.chkBoxReverse.AutoSize = true;
            this.chkBoxReverse.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkBoxReverse.Location = new System.Drawing.Point(14, 14);
            this.chkBoxReverse.Margin = new System.Windows.Forms.Padding(5);
            this.chkBoxReverse.Name = "chkBoxReverse";
            this.chkBoxReverse.Size = new System.Drawing.Size(176, 17);
            this.chkBoxReverse.TabIndex = 3;
            this.chkBoxReverse.Text = "Do you want to Reverse again?";
            this.chkBoxReverse.UseVisualStyleBackColor = true;
            this.chkBoxReverse.CheckedChanged += new System.EventHandler(this.chkBoxReverse_CheckedChanged);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(13, 48);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(0, 13);
            this.lblInfo.TabIndex = 4;
            this.lblInfo.Click += new System.EventHandler(this.lblInfo_Click);
            // 
            // AlignTextToCableFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(246, 73);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.chkBoxReverse);
            this.Name = "AlignTextToCableFrm";
            this.Text = "AlignTextToCableFrm";
            this.Load += new System.EventHandler(this.AlignTextToCableFrm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.CheckBox chkBoxReverse;
        public System.Windows.Forms.Label lblInfo;
    }
}