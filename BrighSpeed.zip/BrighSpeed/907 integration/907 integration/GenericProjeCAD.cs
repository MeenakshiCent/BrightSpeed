﻿using _907_integration;
using IntelliCAD.ApplicationServices;
using IntelliCAD.EditorInput;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Teigha.DatabaseServices;
using Teigha.Geometry;
using Application = IntelliCAD.ApplicationServices.Application;
using System;

namespace LUMENCADPlacementTool
{
    public static class GenericProjeCAD
    {
        // -------------------------------------------------------------------------
        // METHOD 1: MAIN ENTRY POINT
        // Selects the Line/Polyline, checks layer, calculates angle, calls GetText
        // -------------------------------------------------------------------------
        public static void AlignAnno2Cable()
        {
            // Reset selection globals
            Commands.acSSet = null;
            Commands.acSSPrompt = null;

            Editor acDocEd = Application.DocumentManager.MdiActiveDocument.Editor;
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

            // Prompt specifically for SPAN LENGH layer
            PromptEntityOptions options = new PromptEntityOptions("\nSelect Line or Polyline (Layer: SPAN LENGH): ");
            options.SetRejectMessage("\nMust be a line or polyline.");
            options.AddAllowedClass(typeof(Line), true);
            options.AddAllowedClass(typeof(Polyline), true);

            PromptEntityResult result = acDocEd.GetEntity(options);

            if (result.Status != PromptStatus.OK) return;

            ObjectId acObjId = result.ObjectId;

            using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
            {
                Entity acEnt = acTrans.GetObject(acObjId, OpenMode.ForRead) as Entity;

                // -------------------------------------------------------------
                // CRITICAL: CHECK LINE LAYER IS "SPAN LENGH"
                // -------------------------------------------------------------
                if (!acEnt.Layer.Equals("SPAN LENGH", StringComparison.OrdinalIgnoreCase))
                {
                    Application.ShowAlertDialog($"Invalid Layer.\nThe selected object is on layer '{acEnt.Layer}'.\nIt must be on 'SPAN LENGH'.");
                    return;
                }

                if (acEnt is Line pLine)
                {
                    Commands.lineAngle = pLine.Angle;
                    GetText(Commands.lineAngle);
                }
                else if (acEnt is Polyline pl)
                {
                    Point3d pickpnt = result.PickedPoint;
                    Point3d pickp = pl.GetClosestPointTo(pickpnt, false);

                    // Logic to find the specific segment angle based on picked point
                    var dictionary = new Dictionary<int, double>();
                    for (int i = 0; i < pl.NumberOfVertices; i++)
                    {
                        double dist = pickp.DistanceTo(pl.GetPoint3dAt(i));
                        dictionary.Add(i, dist);
                    }

                    // Get the two closest vertices (start and end of the clicked segment)
                    var res = dictionary.OrderBy(pair => pair.Value).ToList();

                    if (res.Count >= 2)
                    {
                        int x = res[0].Key;
                        int y = res[1].Key;

                        Point2d point1, point2;

                        // Ensure direction flows with vertex index
                        if (x < y)
                        {
                            point1 = pl.GetPoint2dAt(x);
                            point2 = pl.GetPoint2dAt(y);
                        }
                        else
                        {
                            point1 = pl.GetPoint2dAt(y);
                            point2 = pl.GetPoint2dAt(x);
                        }

                        // Calculate angle of the segment
                        Vector2d segmentDir = point2 - point1;
                        Commands.lineAngle = segmentDir.Angle;

                        GetText(Commands.lineAngle);
                    }
                }
                acTrans.Commit();
            }
        }

        // -------------------------------------------------------------------------
        // METHOD 2: APPLY ROTATION
        // Filters text on "SPAN_LENGTH" and applies readable angle
        // -------------------------------------------------------------------------
        public static void GetText(double lineAngleInRadians)
        {
            Editor acDocEd = Application.DocumentManager.MdiActiveDocument.Editor;
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

            // 1. Calculate Readable Angle ONCE (Convert Radians -> Degrees -> Fix -> Radians)
            double finalReadableAngle = GetReadableAngle(lineAngleInRadians);

            // 2. Select Text objects if not already selected
            if (Commands.acSSet == null || Commands.acSSPrompt == null)
            {
                // -------------------------------------------------------------
                // CRITICAL: FILTER TEXT ONLY ON LAYER "SPAN_LENGTH"
                // -------------------------------------------------------------
                TypedValue[] filter = new TypedValue[]
                {
                    // Filter 1: Layer Name must be "SPAN_LENGTH"
                    new TypedValue((int)DxfCode.LayerName, "SPAN_LENGTH"), 

                    // Filter 2: Object Types
                    new TypedValue((int)DxfCode.Operator, "<or"),
                    new TypedValue(0, "TEXT"),
                    new TypedValue(0, "MTEXT"),
                    new TypedValue(0, "INSERT"), // Block References
                    new TypedValue((int)DxfCode.Operator, "or>")
                };

                SelectionFilter selFilter = new SelectionFilter(filter);
                Commands.acSSPrompt = acDocEd.GetSelection(selFilter);

                if (Commands.acSSPrompt.Status != PromptStatus.OK)
                {
                    acDocEd.WriteMessage("\nNo valid text found on layer 'SPAN_LENGTH'.");
                    return;
                }
                Commands.acSSet = Commands.acSSPrompt.Value;
            }

            using (DocumentLock doclock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
                {
                    if (Commands.acSSet != null)
                    {
                        Commands.alignTextFrm.lblInfo.Text = "Selected count: " + Commands.acSSet.Count.ToString();

                        foreach (ObjectId acObjId in Commands.acSSet.GetObjectIds())
                        {
                            Entity acEnt = acTrans.GetObject(acObjId, OpenMode.ForWrite) as Entity;
                            if (acEnt == null) continue;

                            // Apply rotation using the calculated angle
                            if (acEnt is DBText textObj)
                            {
                                textObj.Rotation = finalReadableAngle;
                            }
                            else if (acEnt is MText mText)
                            {
                                mText.Rotation = finalReadableAngle;
                            }
                            else if (acEnt is BlockReference blkRef)
                            {
                                blkRef.Rotation = finalReadableAngle;
                                GetDuctlength(blkRef, finalReadableAngle, acTrans);
                            }
                        }
                    }

                    if (Commands.alignTextFrm.Visible == false)
                    {
                        Application.ShowModelessDialog(Commands.alignTextFrm);
                    }
                    acTrans.Commit();
                }
            }
        }

        // -------------------------------------------------------------------------
        // METHOD 3: CALCULATE READABILITY (Math Logic)
        // -------------------------------------------------------------------------
        private static double GetReadableAngle(double angleInRadians)
        {
            // 1. Normalize Radians to 0 - 2PI
            double twoPi = Math.PI * 2.0;
            while (angleInRadians < 0) angleInRadians += twoPi;
            while (angleInRadians >= twoPi) angleInRadians -= twoPi;

            // 2. Convert to Degrees for "Upside Down" check
            double angleInDegrees = angleInRadians * (180.0 / Math.PI);

            // 3. Check if angle is between 90 and 270 (reading backwards/upside down)
            if (angleInDegrees > 90.0 && angleInDegrees <= 270.0)
            {
                angleInDegrees += 180.0;
            }

            // 4. Normalize Degrees back to 0-360
            while (angleInDegrees >= 360.0) angleInDegrees -= 360.0;

            // 5. Return Radians (AutoCAD property expects Radians)
            return angleInDegrees * (Math.PI / 180.0);
        }

        // -------------------------------------------------------------------------
        // METHOD 4: HANDLE BLOCK ATTRIBUTES
        // -------------------------------------------------------------------------
        public static void GetDuctlength(BlockReference ductref, double lineAngle, Transaction acTrans)
        {
            if (ductref == null) return;

            AttributeCollection attCol = ductref.AttributeCollection;
            if (attCol != null)
            {
                foreach (ObjectId attId in attCol)
                {
                    DBObject obj = acTrans.GetObject(attId, OpenMode.ForWrite);

                    // Usually attributes are AttributeReference
                    if (obj is AttributeReference attRef)
                    {
                        attRef.Rotation = lineAngle;
                    }
                    // Sometimes code treats them as DBText, keeping for safety
                    else if (obj is DBText dbText)
                    {
                        dbText.Rotation = lineAngle;
                    }
                }
            }
        }
    }
}











//using _907_integration;
//using IntelliCAD.ApplicationServices;
//using IntelliCAD.EditorInput;
//using System.Collections.Generic;
//using System.Linq;
//using System.Windows.Forms;
//using Teigha.DatabaseServices;
//using Teigha.Geometry;
//using Application = IntelliCAD.ApplicationServices.Application;
//using System;

//namespace LUMENCADPlacementTool
//{
//    public static class GenericProjeCAD
//    {
//        // -------------------------------------------------------------------------
//        // MAIN COMMAND: AUTOMATICALLY ALIGN ALL TEXT TO NEAREST CABLE
//        // -------------------------------------------------------------------------
//        public static void AlignAnno2Cable()
//        {
//            Editor acDocEd = Application.DocumentManager.MdiActiveDocument.Editor;
//            Document acDoc = Application.DocumentManager.MdiActiveDocument;
//            Database acCurDb = acDoc.Database;

//            acDocEd.WriteMessage("\nStarting Automatic Text Alignment...");

//            using (DocumentLock doclock = acDoc.LockDocument())
//            {
//                using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
//                {
//                    // ---------------------------------------------------------
//                    // STEP 1: GET ALL LINES/POLYLINES ON LAYER "SPAN LENGH"
//                    // ---------------------------------------------------------
//                    TypedValue[] lineFilter = new TypedValue[]
//                    {
//                        new TypedValue((int)DxfCode.LayerName, "SPAN LENGH"),
//                        new TypedValue((int)DxfCode.Operator, "<or"),
//                        new TypedValue(0, "LINE"),
//                        new TypedValue(0, "LWPOLYLINE"),
//                        new TypedValue(0, "POLYLINE"),
//                        new TypedValue((int)DxfCode.Operator, "or>")
//                    };

//                    SelectionFilter lineSelFilter = new SelectionFilter(lineFilter);
//                    PromptSelectionResult lineRes = acDocEd.SelectAll(lineSelFilter);

//                    if (lineRes.Status != PromptStatus.OK)
//                    {
//                        acDocEd.WriteMessage("\nError: No Lines or Polylines found on layer 'SPAN LENGH'.");
//                        return;
//                    }

//                    ObjectId[] lineIds = lineRes.Value.GetObjectIds();

//                    // ---------------------------------------------------------
//                    // STEP 2: GET ALL TEXT/BLOCKS ON LAYER "SPAN_LENGTH"
//                    // ---------------------------------------------------------
//                    TypedValue[] textFilter = new TypedValue[]
//                    {
//                        new TypedValue((int)DxfCode.LayerName, "SPAN_LENGTH"),
//                        new TypedValue((int)DxfCode.Operator, "<or"),
//                        new TypedValue(0, "TEXT"),
//                        new TypedValue(0, "MTEXT"),
//                        new TypedValue(0, "INSERT"),
//                        new TypedValue((int)DxfCode.Operator, "or>")
//                    };

//                    SelectionFilter textSelFilter = new SelectionFilter(textFilter);
//                    PromptSelectionResult textRes = acDocEd.SelectAll(textSelFilter);

//                    if (textRes.Status != PromptStatus.OK)
//                    {
//                        acDocEd.WriteMessage("\nError: No Text objects found on layer 'SPAN_LENGTH'.");
//                        return;
//                    }

//                    ObjectId[] textIds = textRes.Value.GetObjectIds();
//                    acDocEd.WriteMessage($"\nProcessing {textIds.Length} text objects against {lineIds.Length} lines...");

//                    // ---------------------------------------------------------
//                    // STEP 3: PROCESS EACH TEXT OBJECT
//                    // ---------------------------------------------------------
//                    foreach (ObjectId txtId in textIds)
//                    {
//                        Entity ent = acTrans.GetObject(txtId, OpenMode.ForWrite) as Entity;
//                        if (ent == null) continue;

//                        Point3d textPosition;

//                        // Get insertion point based on type
//                        if (ent is DBText dbT) textPosition = dbT.Position;
//                        else if (ent is MText mT) textPosition = mT.Location;
//                        else if (ent is BlockReference bR) textPosition = bR.Position;
//                        else continue;

//                        // Find the CLOSEST line and its angle
//                        double bestAngle = GetAngleOfNearestLine(textPosition, lineIds, acTrans);

//                        // Calculate readability (Avoid upside down text)
//                        double readableAngle = GetReadableAngle(bestAngle);

//                        // Apply Rotation
//                        if (ent is DBText dbText)
//                        {
//                            dbText.Rotation = readableAngle;
//                        }
//                        else if (ent is MText mText)
//                        {
//                            mText.Rotation = readableAngle;
//                        }
//                        else if (ent is BlockReference blkRef)
//                        {
//                            blkRef.Rotation = readableAngle;
//                            GetDuctlength(blkRef, readableAngle, acTrans);
//                        }
//                    }

//                    acTrans.Commit();
//                    acDocEd.WriteMessage("\nAutomatic Alignment Complete.");
//                }
//            }
//        }

//        // -------------------------------------------------------------------------
//        // HELPER: FIND NEAREST LINE AND GET ANGLE
//        // -------------------------------------------------------------------------
//        private static double GetAngleOfNearestLine(Point3d textPt, ObjectId[] lineIds, Transaction acTrans)
//        {
//            double minDistance = double.MaxValue;
//            double targetAngle = 0.0;

//            // Loop through all lines to find the physically closest one
//            foreach (ObjectId lineId in lineIds)
//            {
//                Curve curve = acTrans.GetObject(lineId, OpenMode.ForRead) as Curve;
//                if (curve == null) continue;

//                // Find closest point on this curve to the text
//                Point3d closestPtOnCurve = curve.GetClosestPointTo(textPt, false);
//                double dist = textPt.DistanceTo(closestPtOnCurve);

//                if (dist < minDistance)
//                {
//                    minDistance = dist;

//                    // Calculate the angle at this specific point on the curve
//                    if (curve is Line line)
//                    {
//                        targetAngle = line.Angle;
//                    }
//                    else if (curve is Polyline pl)
//                    {
//                        // Use First Derivative (Tangent vector) at the closest point
//                        // This handles curved segments or specific linear segments of a polyline
//                        double param = pl.GetParameterAtPoint(closestPtOnCurve);
//                        Vector3d tangentVec = pl.GetFirstDerivative(param);

//                        // Convert 3D vector to 2D angle
//                        targetAngle = new Vector2d(tangentVec.X, tangentVec.Y).Angle;
//                    }
//                }
//            }

//            return targetAngle;
//        }

//        // -------------------------------------------------------------------------
//        // HELPER: READABILITY LOGIC (RADIANS)
//        // -------------------------------------------------------------------------
//        private static double GetReadableAngle(double angleInRadians)
//        {
//            double twoPi = Math.PI * 2.0;
//            // Normalize to 0 - 2PI
//            while (angleInRadians < 0) angleInRadians += twoPi;
//            while (angleInRadians >= twoPi) angleInRadians -= twoPi;

//            // Convert to Degrees
//            double angleInDegrees = angleInRadians * (180.0 / Math.PI);

//            // Logic: If angle is > 90 and <= 270, it reads "upside down"
//            if (angleInDegrees > 90.0 && angleInDegrees <= 270.0)
//            {
//                angleInDegrees += 180.0;
//            }

//            // Normalize back to 0-360
//            while (angleInDegrees >= 360.0) angleInDegrees -= 360.0;

//            // Return Radians
//            return angleInDegrees * (Math.PI / 180.0);
//        }

//        // -------------------------------------------------------------------------
//        // HELPER: BLOCK ATTRIBUTES
//        // -------------------------------------------------------------------------
//        public static void GetDuctlength(BlockReference ductref, double lineAngle, Transaction acTrans)
//        {
//            if (ductref == null) return;

//            AttributeCollection attCol = ductref.AttributeCollection;
//            if (attCol != null)
//            {
//                foreach (ObjectId attId in attCol)
//                {
//                    DBObject obj = acTrans.GetObject(attId, OpenMode.ForWrite);

//                    if (obj is AttributeReference attRef)
//                    {
//                        attRef.Rotation = lineAngle;
//                    }
//                    else if (obj is DBText dbText)
//                    {
//                        dbText.Rotation = lineAngle;
//                    }
//                }
//            }
//        }
//    }
//}
