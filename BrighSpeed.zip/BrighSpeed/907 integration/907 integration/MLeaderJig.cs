﻿
using IntelliCAD.ApplicationServices;
using IntelliCAD.EditorInput;
using System.Windows.Forms;
using Teigha.DatabaseServices;
using Teigha.Geometry;
using Application = IntelliCAD.ApplicationServices.Application;

namespace LUMENCADPlacementTool
{
    public class MLeaderJig : EntityJig
    {
        //        class MLeaderJig : EntityJig
        public Point3dCollection m_pts;
        Point3d m_tempPoint;
        string m_contents;
        int m_leaderIndex;
        public int m_leaderLineIndex;
        public Point3d p_mlpoint = new Point3d();


        public MLeaderJig(string contents) : base(new MLeader())

        {
            Document acDoc = IntelliCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database acdb = acDoc.Database;
            Editor acEditor = acDoc.Editor;
            ObjectId styleId = ObjectId.Null;
            using (DocumentLock @dLock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acdb.TransactionManager.StartTransaction())
                {
                    // Store the string passed in
                    m_contents = contents;
                    // Create a point collection to store our vertices
                    m_pts = new Point3dCollection();

                    // Create mleader and set defaults
                    MLeader ml = Entity as MLeader;
                    //ml.SetDatabaseDefaults();
                    //DBDictionary mlDictionary = (DBDictionary)acTrans.GetObject(acdb.MLeaderStyleDictionaryId, OpenMode.ForRead);
                    //if (mlDictionary.Contains("Standard"))
                    //{
                    //    styleId = mlDictionary.GetAt("Standard");
                    //    MLeaderStyle style = acTrans.GetObject(styleId, OpenMode.ForWrite) as MLeaderStyle;
                    //    if (style != null)
                    //    {
                    // GetStyle();
                    //new MLeaderStyle();
                    //mldr.TextAttachmentType = TextAttachmentType.AttachmentMiddle;
                    //mldr.TextAttachmentDirection = TextAttachmentDirection.AttachmentHorizontal;
                    //mldr.DrawMLeaderOrderType = DrawMLeaderOrderType.DrawLeaderFirst;
                    //mldr.ContentType = ContentType.MTextContent;
                    //mldr.TextAlignmentType = TextAlignmentType.CenterAlignment;
                    //mldr.TextAttachmentType = TextAttachmentType.AttachmentMiddle;
                    //mldr.TextHeight = 10;
                    //mldr.TextAngleType = TextAngleType.HorizontalAngle;
                    //mldr.ArrowSize = 10;
                    // Set up the MText contents
                    // ml.MLeaderStyle=
                    MLeaderStyle mldr = GetStyle();
                    ml.MLeaderStyle = mldr.ObjectId;
                    ml.ContentType = ContentType.MTextContent;
                    MText mt = new MText();

                    mt.SetDatabaseDefaults();
                    //mt.TextStyleId = mldr.TextStyleId;
                    mt.Attachment = AttachmentPoint.MiddleCenter;
                    mt.Contents = m_contents;
                    mt.Height = 10;
                    mt.Layer = "Text";
                    ml.MText = mt;
                    //ml.TextAlignmentType = TextAlignmentType.CenterAlignment;
                    //ml.TextAttachmentType = TextAttachmentType.AttachmentMiddle;
                    //ml.TextAttachmentDirection = TextAttachmentDirection.AttachmentHorizontal;
                    // mt.Location = ml.TextLocation;
                    // Set the frame and landing properties
                    ml.EnableDogleg = true;
                    ml.EnableFrameText = false;
                    ml.EnableLanding = true;
                    //ml.ExtendLeaderToText = true;
                    // Reduce the standard landing gap
                    ml.LandingGap = 10.6;// 0.0900;
                                         // Add a leader, but not a leader line (for now)
                    m_leaderIndex = ml.AddLeader();
                    m_leaderLineIndex = -1;


                    acTrans.Commit();
                }
            }
        }
        public static MLeaderStyle GetStyle()
        {
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acdb = acDoc.Database;
            Editor acEditor = acDoc.Editor;
            ObjectId styleId = ObjectId.Null;
            using (DocumentLock @dLock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acdb.TransactionManager.StartTransaction())
                {
                    // MLeader ml = new MLeader();
                    // ml.SetDatabaseDefaults();
                    MLeaderStyle mldr = new MLeaderStyle();
                    DBDictionary mlDictionary = (DBDictionary)acTrans.GetObject(acdb.MLeaderStyleDictionaryId, OpenMode.ForRead);
                    if (mlDictionary.Contains("Standard"))
                    {
                        styleId = mlDictionary.GetAt("Standard");
                        MLeaderStyle style = acTrans.GetObject(styleId, OpenMode.ForWrite) as MLeaderStyle;
                        if (style != null)
                        {
                            mldr = style;  // existing MLeaderStyle

                            // TEXT + LEADER SETUP
                            mldr.ContentType = ContentType.MTextContent;
                            mldr.TextHeight = 10;

                            // TEXT ATTACHMENT
                            mldr.TextAttachmentType = TextAttachmentType.AttachmentMiddleOfTop;
                            mldr.TextAttachmentDirection = TextAttachmentDirection.AttachmentHorizontal;
                            mldr.TextAlignmentType = TextAlignmentType.CenterAlignment;
                            mldr.TextAngleType = TextAngleType.HorizontalAngle;

                            // DRAW ORDER
                            mldr.DrawLeaderOrderType = DrawLeaderOrderType.DrawLeaderHeadFirst;
                            mldr.DrawMLeaderOrderType = DrawMLeaderOrderType.DrawLeaderFirst;

                            // ARROW SIZE
                            mldr.ArrowSize = 10;

                            // Landing enabled (necessary because ExtendLeaderToText is not supported)
                            mldr.EnableLanding = true;
                            mldr.LandingGap = 1.0;

                            // Apply style to database
                            acdb.MLeaderstyle = mldr.ObjectId;
                        }

                    }

                    acTrans.Commit();
                    return mldr;
                }
                return null;
            }
        }
        public static MLeaderStyle GetStylePlacement()
        {
            Document acDoc = IntelliCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database acdb = acDoc.Database;
            Editor acEditor = acDoc.Editor;
            ObjectId styleId = ObjectId.Null;
            using (DocumentLock @dLock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acdb.TransactionManager.StartTransaction())
                {
                    // MLeader ml = new MLeader();
                    // ml.SetDatabaseDefaults();
                    MLeaderStyle mldr = new MLeaderStyle();
                    DBDictionary mlDictionary = (DBDictionary)acTrans.GetObject(acdb.MLeaderStyleDictionaryId, OpenMode.ForRead);
                    if (mlDictionary.Contains("Standard"))
                    {
                        styleId = mlDictionary.GetAt("Standard");
                        MLeaderStyle style = acTrans.GetObject(styleId, OpenMode.ForWrite) as MLeaderStyle;
                        if (style != null)
                        {
                            mldr = style;//new MLeaderStyle();
                                         //mldr.TextAttachmentType = TextAttachmentType.AttachmentLinedCenter;
                            mldr.TextAttachmentDirection = TextAttachmentDirection.AttachmentHorizontal;
                            mldr.DrawMLeaderOrderType = DrawMLeaderOrderType.DrawLeaderFirst;
                            mldr.ContentType = ContentType.MTextContent;
                            mldr.TextAlignmentType = TextAlignmentType.CenterAlignment;
                            mldr.DrawLeaderOrderType = DrawLeaderOrderType.DrawLeaderHeadFirst;
                            mldr.DrawMLeaderOrderType = DrawMLeaderOrderType.DrawLeaderFirst;
                            // mldr.ExtendLeaderToText = true;

                            mldr.TextHeight = 10;
                            mldr.TextAngleType = TextAngleType.HorizontalAngle;
                            mldr.ArrowSize = 10;
                            //acdb.Dimldrblk = ".";
                            acdb.MLeaderstyle = mldr.ObjectId;
                        }
                    }

                    acTrans.Commit();
                    return mldr;
                }
                return null;
            }
        }

        protected override SamplerStatus Sampler(JigPrompts prompts)
        {

            JigPromptPointOptions opts = new JigPromptPointOptions();


            // Not all options accept null response
            opts.UserInputControls = (UserInputControls.Accept3dCoordinates | UserInputControls.NoNegativeResponseAccepted);
            // Get the first point
            if (m_pts.Count == 0)
            {
                opts.UserInputControls |= UserInputControls.NullResponseAccepted;
                opts.Message = "\nStart point of multileader: ";
                opts.UseBasePoint = false;
            }

            // And the second
            else if (m_pts.Count == 1)
            {
                opts.BasePoint = m_pts[m_pts.Count - 1];
                opts.UseBasePoint = true;
                opts.Message =
                  "\nSpecify multileader vertex: ";
            }

            // And subsequent points

            else if (m_pts.Count > 1)
            {
                opts.UserInputControls |= UserInputControls.NullResponseAccepted;
                opts.BasePoint = m_pts[m_pts.Count - 1];
                opts.UseBasePoint = true;
                opts.SetMessageAndKeywords("\nSpecify multileader vertex or [End]: ", "End");
            }

            else // Should never happen

                return SamplerStatus.Cancel;


            PromptPointResult res = prompts.AcquirePoint(opts);
            if (res.Status == PromptStatus.Keyword)
            {
                if (res.StringResult == "End")
                {
                    return SamplerStatus.Cancel;
                }

            }
            if (m_tempPoint == res.Value)
            {
                return SamplerStatus.NoChange;
            }

            else if (res.Status == PromptStatus.OK)
            {
                m_tempPoint = res.Value;
                return SamplerStatus.OK;
            }
            return SamplerStatus.Cancel;
        }
        protected override bool Update()
        {
            try
            {
                if (m_pts.Count > 0)
                {
                    // Set the last vertex to the new value
                    MLeader ml = Entity as MLeader;
                    ml.SetLastVertex(m_leaderLineIndex, m_tempPoint);
                    // Adjust the text location
                    Vector3d dogvec = ml.GetDogleg(m_leaderIndex);
                    double doglen = ml.DoglegLength;
                    double landgap = ml.LandingGap;
                    ml.TextLocation = m_tempPoint;// + ((doglen + landgap) * dogvec);
                    p_mlpoint = m_tempPoint;
                }
            }
            catch (System.Exception ex)
            {
                Document doc = IntelliCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
                doc.Editor.WriteMessage("\nException: " + ex.Message);
                return false;
            }
            return true;
        }
        public void AddVertex()
        {
            MLeader ml = Entity as MLeader;
            // For the first point...
            if (m_pts.Count == 0)
            {
                // Add a leader line
                m_leaderLineIndex = ml.AddLeaderLine(m_leaderIndex);
                // And a start vertex
                ml.AddFirstVertex(m_leaderLineIndex, m_tempPoint);
                // Add a second vertex that will be set
                // within the jig
                ml.AddLastVertex(m_leaderLineIndex, new Point3d(0, 0, 0));
            }
            else
            {
                // For subsequent points,
                // just add a vertex
                ml.AddLastVertex(m_leaderLineIndex, m_tempPoint);
            }
            // Reset the attachment point, otherwise
            // it seems to get forgotten

            ml.TextAttachmentType = TextAttachmentType.AttachmentMiddle;
            // Add the latest point to our history
            m_pts.Add(m_tempPoint);
        }
        public void RemoveLastVertex()
        {
            // We don't need to actually remove
            // the vertex, just reset it
            MLeader ml = Entity as MLeader;
            if (m_pts.Count >= 1)
            {
                Vector3d dogvec = ml.GetDogleg(m_leaderIndex);
                double doglen = ml.DoglegLength;
                double landgap = ml.LandingGap;
                ml.TextLocation = m_pts[m_pts.Count - 1];// + ((doglen + landgap) * dogvec);
            }
        }
        public Entity GetEntity()
        {
            return Entity;
        }
    }

}







