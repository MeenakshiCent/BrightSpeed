﻿using LUMENCADPlacementTool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teigha.Runtime;
using IntelliCAD.EditorInput;


namespace _907_integration
{
    public class Commands
    {
        public static AlignTextToCableFrm alignTextFrm = null;
        public static double lineAngle;
        //public static Object acSSet;
        //public static Object acSSPrompt;
        public static SelectionSet acSSet;
        public static PromptSelectionResult acSSPrompt;

        [CommandMethod("ALP")]
        public static void AlignAnnoToCable()
        {
            if (alignTextFrm == null || alignTextFrm.IsDisposed)
            {
                alignTextFrm = new AlignTextToCableFrm();

            }
            GenericProjeCAD.AlignAnno2Cable();
        }
    }
}
