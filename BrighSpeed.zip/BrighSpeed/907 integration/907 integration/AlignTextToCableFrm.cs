﻿using IntelliCAD.ApplicationServices;
using LUMENCADPlacementTool;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _907_integration
{
    public partial class AlignTextToCableFrm : Form
    {
        //internal object lblInfo;

        public AlignTextToCableFrm()
        {
            InitializeComponent();
        }

        private void chkBoxReverse_CheckedChanged(object sender, EventArgs e)
        {
            // if(checkBox1.Checked)
            // {
            double ang = Commands.lineAngle;

            //SelectionSet acSet = clsnw.acSSet;
            if (ang < 3.14159)
            {
                ang = ang + 3.14159;

            }
            else
            {
                ang = ang - 3.14159;
            }
            //GenericProjeCAD.GetText(ang);
            Commands.lineAngle = ang;
            //}
            Document acDoc = IntelliCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            acDoc.Window.Focus();
            //Vector3d lineDirection = line.GetFirstDerivative(pointOverLine);
            //Vector3d blockDirection = minPoint.GetVectorTo(new Point3d(maxPoint.X, minPoint.Y, 0)); // basically a X vector
            //double angleToRotate = lineDirection.GetAngleTo(blockDirection);
            //Matrix3d blockRotate = Matrix3d.Rotation(angleToRotate, Vector3d.ZAxis, pointOverLine);
            //blockRef.TransformBy(blockRotate);
        }

        private void AlignTextToCableFrm_Load(object sender, EventArgs e)
        {

        }

        private void lblInfo_Click(object sender, EventArgs e)
        {

        }
    }
}

