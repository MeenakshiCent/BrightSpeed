﻿using IntelliCAD.ApplicationServices;
using IntelliCAD.EditorInput;
using IntelliCAD.Runtime; 
using System;
using Teigha.DatabaseServices;
using Teigha.Geometry;
using Teigha.Runtime;
using Application = IntelliCAD.ApplicationServices.Application;

namespace LUMENCADPlacementTool
{
    public class GenericProjeCAD
    {
        
        [CommandMethod("ALIGN_ANNO")]
        public void AlignAnno2Cable()
        {
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;
            Editor acDocEd = acDoc.Editor;

            acDocEd.WriteMessage("\n--- Starting Automatic Text Alignment ---");

            using (DocumentLock doclock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
                {
                    TypedValue[] lineFilter = new TypedValue[]
                    {
                        new TypedValue((int)DxfCode.LayerName, "SPAN LENGH"),
                        new TypedValue((int)DxfCode.Operator, "<or"),
                        new TypedValue(0, "LINE"),
                        new TypedValue(0, "LWPOLYLINE"),
                        new TypedValue(0, "POLYLINE"),
                        new TypedValue((int)DxfCode.Operator, "or>")
                    };

                    SelectionFilter lineSelFilter = new SelectionFilter(lineFilter);
                    PromptSelectionResult lineRes = acDocEd.SelectAll(lineSelFilter);

                    if (lineRes.Status != PromptStatus.OK)
                    {
                        acDocEd.WriteMessage("\nError: No geometry found on layer 'SPAN LENGH'.");
                        return;
                    }

                    ObjectId[] lineIds = lineRes.Value.GetObjectIds();

                
                    TypedValue[] textFilter = new TypedValue[]
                    {
                        new TypedValue((int)DxfCode.LayerName, "SPAN_LENGTH"),
                        new TypedValue((int)DxfCode.Operator, "<or"),
                        new TypedValue(0, "TEXT"),
                        new TypedValue(0, "MTEXT"),
                        new TypedValue(0, "INSERT"), 
                        new TypedValue((int)DxfCode.Operator, "or>")
                    };

                    SelectionFilter textSelFilter = new SelectionFilter(textFilter);
                    PromptSelectionResult textRes = acDocEd.SelectAll(textSelFilter);

                    if (textRes.Status != PromptStatus.OK)
                    {
                        acDocEd.WriteMessage("\nError: No Text/Blocks found on layer 'SPAN_LENGTH'.");
                        return;
                    }

                    ObjectId[] textIds = textRes.Value.GetObjectIds();
                    acDocEd.WriteMessage($"\nFound  annotations. Aligning to  cables...");
                    //acDocEd.WriteMessage($"\nFound {textIds.Length} annotations. Aligning to {lineIds.Length} cables...");

           
                    int processedCount = 0;
                    foreach (ObjectId txtId in textIds)
                    {
                        Entity ent = acTrans.GetObject(txtId, OpenMode.ForWrite) as Entity;
                        if (ent == null) continue;
                        Point3d entityPosition;
                        if (ent is DBText dbT) entityPosition = dbT.Position;
                        else if (ent is MText mT) entityPosition = mT.Location;
                        else if (ent is BlockReference bR) entityPosition = bR.Position;
                        else continue;
                        double cableAngle = GetAngleOfNearestLine(entityPosition, lineIds, acTrans);
                        double finalRotation = GetReadableAngle(cableAngle);
                        if (ent is DBText dbText)
                        {
                            dbText.Rotation = finalRotation;
                        }
                        else if (ent is MText mText)
                        {
                            mText.Rotation = finalRotation;
                        }
                        else if (ent is BlockReference blkRef)
                        {
                            
                            blkRef.Rotation = finalRotation;
                        }
                        processedCount++;
                    }

                    acTrans.Commit();
                    acDocEd.WriteMessage($"\nSuccess: Aligned  objects.");
                    //acDocEd.WriteMessage($"\nSuccess: Aligned {processedCount} objects.");
                }
            }
        }

        private static double GetAngleOfNearestLine(Point3d textPt, ObjectId[] lineIds, Transaction acTrans)
        {
            double minDistance = double.MaxValue;
            double targetAngle = 0.0;
            Point3d textPt2D = new Point3d(textPt.X, textPt.Y, 0);
            foreach (ObjectId lineId in lineIds)
            {
                Curve curve = acTrans.GetObject(lineId, OpenMode.ForRead) as Curve;
                if (curve == null) continue;
                Point3d closestPtOnCurve = curve.GetClosestPointTo(textPt, false);
                Point3d closestPt2D = new Point3d(closestPtOnCurve.X, closestPtOnCurve.Y, 0);
                double dist = closestPt2D.DistanceTo(textPt2D);
                if (dist < minDistance)
                {
                    minDistance = dist;
                    if (curve is Line line)
                    {
                        targetAngle = line.Angle;
                    }
                    else if (curve is Polyline pl)
                    {
                        double param = pl.GetParameterAtPoint(closestPtOnCurve);
                        Vector3d tangent = pl.GetFirstDerivative(param);
                        targetAngle = new Vector2d(tangent.X, tangent.Y).Angle;
                    }
                }
            }
            return targetAngle;
        }
        private static double GetReadableAngle(double angleInRadians)
        {
            double twoPi = Math.PI * 2.0;
            while (angleInRadians < 0) angleInRadians += twoPi;
            while (angleInRadians >= twoPi) angleInRadians -= twoPi;
            double degrees = angleInRadians * (180.0 / Math.PI);
            if (degrees > 90.0 && degrees <= 270.0)
            {
                degrees += 180.0;
            }
            while (degrees >= 360.0) degrees -= 360.0;
            return degrees * (Math.PI / 180.0);
        }
    }
}