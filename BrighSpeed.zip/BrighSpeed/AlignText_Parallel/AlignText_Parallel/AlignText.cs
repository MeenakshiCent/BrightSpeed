﻿//using _907_integration;
using IntelliCAD.ApplicationServices;
using IntelliCAD.EditorInput;
using IntelliCAD.Runtime; // Required for [CommandMethod]
using System;
using System.Collections.Generic;
using System.Linq;
using Teigha.DatabaseServices;
using Teigha.Geometry;
using Teigha.Runtime;
using Application = IntelliCAD.ApplicationServices.Application;

namespace LUMENCADPlacementTool
{
    public class GenericProjeCAD1
    {
      
        [CommandMethod("ALIGN_ANY")]
        public void AlignAnno2Cable()
        {
            Editor acDocEd = Application.DocumentManager.MdiActiveDocument.Editor;
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

            PromptEntityOptions options = new PromptEntityOptions("\nSelect Reference Line or Polyline: ");
            options.SetRejectMessage("\nMust be a line or polyline.");
            options.AddAllowedClass(typeof(Line), true);
            options.AddAllowedClass(typeof(Polyline), true);

            PromptEntityResult result = acDocEd.GetEntity(options);

            if (result.Status != PromptStatus.OK) return;

            ObjectId acObjId = result.ObjectId;
            double calculatedAngle = 0.0;

            using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
            {
                Entity acEnt = acTrans.GetObject(acObjId, OpenMode.ForRead) as Entity;

                if (acEnt is Line pLine)
                {
                    calculatedAngle = pLine.Angle;
                }
             
                else if (acEnt is Polyline pl)
                {
                    Point3d pickpnt = result.PickedPoint;
                    Point3d pickp = pl.GetClosestPointTo(pickpnt, false);

                    var dictionary = new Dictionary<int, double>();
                    for (int i = 0; i < pl.NumberOfVertices; i++)
                    {
                        double dist = pickp.DistanceTo(pl.GetPoint3dAt(i));
                        dictionary.Add(i, dist);
                    }

                    var res = dictionary.OrderBy(pair => pair.Value).ToList();

                    if (res.Count >= 2)
                    {
                        int x = res[0].Key;
                        int y = res[1].Key;

                        Point2d point1, point2;

                       
                        if (x < y)
                        {
                            point1 = pl.GetPoint2dAt(x);
                            point2 = pl.GetPoint2dAt(y);
                        }
                        else
                        {
                            point1 = pl.GetPoint2dAt(y);
                            point2 = pl.GetPoint2dAt(x);
                        }

                        Vector2d segmentDir = point2 - point1;
                        calculatedAngle = segmentDir.Angle;
                    }
                }

                acTrans.Commit();
            }

          
            GetText(calculatedAngle);
        }

        public static void GetText(double lineAngleInRadians)
        {
            Editor acDocEd = Application.DocumentManager.MdiActiveDocument.Editor;
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

           
            double finalReadableAngle = GetReadableAngle(lineAngleInRadians);

       
            TypedValue[] filter = new TypedValue[]
            {
                new TypedValue((int)DxfCode.Operator, "<or"),
                new TypedValue(0, "TEXT"),
                new TypedValue(0, "MTEXT"),
                new TypedValue(0, "INSERT"), // Block References
                new TypedValue((int)DxfCode.Operator, "or>")
            };

            SelectionFilter selFilter = new SelectionFilter(filter);

            acDocEd.WriteMessage("\nSelect Text, MText, or Blocks to align: ");
            PromptSelectionResult selResult = acDocEd.GetSelection(selFilter);

            if (selResult.Status != PromptStatus.OK)
            {
                acDocEd.WriteMessage("\nSelection canceled or no valid objects found.");
                return;
            }

           
            SelectionSet acSSet = selResult.Value;

            using (DocumentLock doclock = acDoc.LockDocument())
            {
                using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
                {
                    if (acSSet != null)
                    {
                       
                        foreach (ObjectId acObjId in acSSet.GetObjectIds())
                        {
                            Entity acEnt = acTrans.GetObject(acObjId, OpenMode.ForWrite) as Entity;
                            if (acEnt == null) continue;

                          
                            if (acEnt is DBText textObj)
                            {
                                textObj.Rotation = finalReadableAngle;
                            }
                            else if (acEnt is MText mText)
                            {
                                mText.Rotation = finalReadableAngle;
                            }
                            else if (acEnt is BlockReference blkRef)
                            {
                                blkRef.Rotation = finalReadableAngle;
                              
                                GetDuctlength(blkRef, finalReadableAngle, acTrans);
                            }
                        }
                    }

                    acTrans.Commit();
                }
            }
        }

        private static double GetReadableAngle(double angleInRadians)
        {
            double twoPi = Math.PI * 2.0;
            while (angleInRadians < 0) angleInRadians += twoPi;
            while (angleInRadians >= twoPi) angleInRadians -= twoPi;
            double degrees = angleInRadians * (180.0 / Math.PI);
            if (degrees > 90.0 && degrees <= 270.0)
            {
                degrees += 180.0;
            }
            while (degrees >= 360.0) degrees -= 360.0;
            return degrees * (Math.PI / 180.0);
        }
        public static void GetDuctlength(BlockReference ductref, double lineAngle, Transaction acTrans)
        {
            if (ductref == null) return;

            AttributeCollection attCol = ductref.AttributeCollection;
            if (attCol != null)
            {
                foreach (ObjectId attId in attCol)
                {
                    DBObject obj = acTrans.GetObject(attId, OpenMode.ForWrite);

                    if (obj is AttributeReference attRef)
                    {
                      
                        attRef.Rotation = lineAngle;
                    }
                    else if (obj is DBText dbText)
                    {
                        dbText.Rotation = lineAngle;
                    }
                }
            }
        }
    }
}